﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text;
//using Microsoft.Msagl;
using System.Timers;
using System.Text.RegularExpressions;

namespace AutoGraph01
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            
            
            DateTime beforDT = System.DateTime.Now; 

            ////Application.EnableVisualStyles();
            ////Application.SetCompatibleTextRenderingDefault(false);
            ////Application.Run(new Form1());

            ////create a form 
            //System.Windows.Forms.Form form = new System.Windows.Forms.Form();
            ////create a viewer object 
            //Microsoft.Msagl.GraphViewerGdi.GViewer viewer = new Microsoft.Msagl.GraphViewerGdi.GViewer();
            ////create a graph object 
            //Microsoft.Msagl.Drawing.Graph graph = new Microsoft.Msagl.Drawing.Graph("graph");
            ////create the graph content 
            //graph.AddEdge("A", "B");
            //graph.AddEdge("B", "A");
            //graph.AddEdge("B", "D");
            //graph.AddEdge("B", "C");
            //graph.AddEdge("A", "C").Attr.Color = Microsoft.Msagl.Drawing.Color.Blue;
            //graph.FindNode("A").Attr.FillColor = Microsoft.Msagl.Drawing.Color.Magenta;
            //graph.FindNode("B").Attr.FillColor = Microsoft.Msagl.Drawing.Color.MistyRose;
            //Microsoft.Msagl.Drawing.Node c = graph.FindNode("C");
            //c.Attr.FillColor = Microsoft.Msagl.Drawing.Color.PaleGreen;
            //c.Attr.Shape = Microsoft.Msagl.Drawing.Shape.Diamond;
            //graph.FindNode("D").Attr.Shape = Microsoft.Msagl.Drawing.Shape.House;
            ////bind the graph to the viewer 
            //viewer.Graph = graph;
            ////associate the viewer with the form 
            //form.SuspendLayout();
            //viewer.Dock = System.Windows.Forms.DockStyle.Fill;
            //form.Controls.Add(viewer);
            //form.ResumeLayout();
            ////show the form 
            //form.ShowDialog();

            //数组
            ////string[,] str = new string[2, 2] { { "1111111111", "222222222222222" }, { "3333333333333", "4444444444" } };
            ////Console.WriteLine("{0}", str[1, 1]);
            ////Console.WriteLine("1111111111111111111111111111111111111111111111111");

            ////List<List<string>> array = new List<List<string>>();
            ////List<string> item = new List<string>(new string[] { "p1", "p2", "c1", "c2", "c3" });
            ////array.Add(item);
            ////item = new List<string>(new string[] { "a", "b", "c", "d", "e" });
            ////array.Add(item);
            ////for (int i = 0; i < 2; i++)
            ////{
            ////    for (int j = 0; j < 5; j++)
            ////    {
            ////        string m = array[i][j];
            ////        Console.Write(m + "\t");
            ////    }
            ////    Console.WriteLine();
            ////}

            ////List<List<string>> array1 = new List<List<string>>();
            ////List<string> item1 = new List<string>(new string[] { "a", "b", "c", "d", "e" });
            ////array1.Add(item1);
            ////item1 = new List<string>(new string[] { "p1", "p2", "c1", "c2", "c3" });
            ////array1.Add(item1);

            ////for (int i = 0; i < 5; i++)
            ////{
            ////    if (array[0][i] == array1[1][i])
            ////    {
            ////        Console.WriteLine("array--->array1");
            ////    }
            ////}



            DataTable tblDatas = new DataTable("Datas");
            DataColumn dc = null;

            //赋值给dc，是便于对每一个datacolumn的操作 
            dc = tblDatas.Columns.Add("ID", Type.GetType("System.Int32"));
            dc.AutoIncrement = true;//自动增加 
            dc.AutoIncrementSeed = 1;//起始为1 
            dc.AutoIncrementStep = 1;//步长为1 
            dc.AllowDBNull = false;// 

            dc = tblDatas.Columns.Add("Product", Type.GetType("System.String"));
            dc = tblDatas.Columns.Add("consumes", Type.GetType("System.String"));
           // dc = tblDatas.Columns.Add("Description", Type.GetType("System.String"));

            DataRow newRow;
            newRow = tblDatas.NewRow();
            newRow["Product"] = "Agefia1";
            newRow["consumes"] = "Bgefia1";
            tblDatas.Rows.Add(newRow);

            newRow = tblDatas.NewRow();
            newRow["Product"] = "Agefia2";
            newRow["consumes"] = "Bgefia2";
            tblDatas.Rows.Add(newRow);

             newRow = tblDatas.NewRow();
             newRow["Product"] = "Agefia3";
             newRow["consumes"] = "Bgefia4";
             
             tblDatas.Rows.Add(newRow);

             newRow = tblDatas.NewRow();
             newRow["consumes"] = "Cgefia1";
             tblDatas.Rows.Add(newRow);

             newRow = tblDatas.NewRow();
             newRow["consumes"] = "Cgefia2";
             tblDatas.Rows.Add(newRow);

             newRow = tblDatas.NewRow();
             newRow["consumes"] = "Cgefia3";
             tblDatas.Rows.Add(newRow);


            //for (int i = 0; i < tblDatas.Rows.Count; i++)
            //{
            //    Console.WriteLine(tblDatas.Rows[i]["Product"].ToString() );//行集合.行【号】列【名】
            //}
            //for (int i = 0; i < tblDatas.Rows.Count; i++)
            //{
            //    Console.WriteLine(tblDatas.Rows[i]["consumes"].ToString() );//行集合.行【号】列【名】
            //}


            //for (int i = 0; i < tblDatas.Rows.Count; i++)
            for (int i = 0; i < 3; i++)
            {
                 Console.WriteLine(tblDatas.Rows[i]["Product"].ToString() );
                //string str1 = tblDatas.Rows[i]["Product"].ToString();
                //string str2 = tblDatas.Rows[i]["consumes"].ToString();
               
                string[] pArray = Regex.Split(tblDatas.Rows[i]["Product"].ToString(), "gefi");
                int len = pArray.Length;

                for (int j = 0; j < tblDatas.Rows.Count; j++)
                {
                    Console.WriteLine(tblDatas.Rows[j]["consumes"].ToString());
                    string[] cArray = Regex.Split(tblDatas.Rows[j]["consumes"].ToString(), "gefi");
                    int len1 = cArray.Length;
                    Console.WriteLine(cArray[1].ToString());
                    if (pArray[1].ToString() == cArray[1].ToString())
                    {
                        Console.WriteLine(cArray[0].ToString() + "------>" + pArray[0].ToString());
                    }
                    Console.WriteLine("j = " + j);
                    //Console.WriteLine(len1);
                }

              
                //foreach (string k in sArray) Console.WriteLine(k.ToString() + "<br>");
                //Console.WriteLine(pArray[1].ToString());
                Console.WriteLine(len);
                //Console.WriteLine(len1);
                Console.WriteLine("i = " + i);

            }


             String[] str = new String[100];  
           StreamReader sr = new StreamReader("C:\\WorkRoom\\GraphDemo\\inf\\A.inf",System.Text.Encoding.Default);  
          //for (int i = 0; i < 100;i++ )  
          // {  
          //     str[i] = sr.ReadLine();
          //     if (str[i] == "[Protocols]")
          //     Console.WriteLine("-----------"+str[i]);
          // }  
           string line;
           int p = 0;
           int q = 0;
           int nump = 0, numq = 0;
           int rownumstart = 0;
           int rownumstart1 = 0;
           int rownumend = 0;
           string input = "[Guids]   ## BY_START   gEfiDiskInfoProtocolGuid  [Protocols]";
            string pattern = @"^\[[\w]*\]";
            string regex = null;
            
                foreach (Match match in Regex.Matches(input, pattern))
                {
                    Console.WriteLine(match.Value);
                    regex = match.Value;
                }
                Console.WriteLine("regex : " + regex);

           
           
            List<string> list = new List<string>();
            //while ((line = sr.ReadLine()) != null)
            //{
            //    if (!(line.Contains("[Protocols]"))) 
            //    {
            //        p++;
            //        rownumstart++;
            //        q = p;
            //        if (!(line.Contains("[Guids]")))
            //        {
            //            q++;
            //        }
            //        else
            //        {
            //            numq =  q;
            //            Console.WriteLine("line " + (numq) + "  " + line);
            //        }

            //    }
            //    else
            //    {
            //        Console.WriteLine("line " + (p) + "  " + line);
            //        nump = p;
            //    }
            //}
            int counter = 0;
            while ((line = sr.ReadLine()) != null)
            {            
                if (line.Contains("[Protocols]"))
                {
                    nump = counter;
                    Console.WriteLine("line " + (numq) + "  " + line);
                }
                else if (line.Contains(regex))
                {
                    numq = counter;
                    Console.WriteLine("line " + (numq) + "  " + line);
                    break;
                }
                counter++;
            }
            
            Console.WriteLine("=====rownumstart = " +rownumstart);
            Console.WriteLine("p = " + nump +"    q = "+numq);

            Console.WriteLine();


            // Director("C:\\ets-poc\\Build\\MdeModule1\\DEBUG_VS2013x86"); 

            //计时器
            DateTime afterDT = System.DateTime.Now;  
            TimeSpan ts = afterDT.Subtract(beforDT);  
            Console.WriteLine("DateTime spend {0}s.", ts.TotalMilliseconds/1000);  

        }
        //读取文件夹及其子文件的文件路径
        static void Director(string dir)
        {
            DirectoryInfo d = new DirectoryInfo(dir);
            FileSystemInfo[] fsinfos = d.GetFileSystemInfos();
            foreach (FileSystemInfo fsinfo in fsinfos)
            {
                if (fsinfo is DirectoryInfo)     //判断是否为文件夹  
                {
                    Director(fsinfo.FullName);//递归调用  
                }
                else
                {
                    Console.WriteLine(fsinfo.FullName);//输出文件的全部路径  
                }
            }
        }
    }

}


